drop database if exists 'demo-small';
create database 'demo-small';
