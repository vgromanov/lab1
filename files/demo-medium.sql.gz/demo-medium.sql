drop database if exists 'demo-medium';
create database 'demo-medium';
